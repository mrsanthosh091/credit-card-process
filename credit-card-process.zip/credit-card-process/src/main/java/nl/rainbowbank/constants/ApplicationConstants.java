package nl.rainbowbank.constants;

public class ApplicationConstants {

	public static String PROCESS_KEY="credit-card-process";
	
}
