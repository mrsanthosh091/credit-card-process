package nl.rainbowbank.services;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class RegisterProductDelegate implements JavaDelegate{

	private final static Logger LOGGER = Logger.getLogger("RegisterProductDelegate");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		execution.setVariable("cardStatus", "Registered");
		String userName = (String) execution.getVariable("firstName");
		LOGGER.info("Credit card is registered to user: "+ userName);
	}
}
