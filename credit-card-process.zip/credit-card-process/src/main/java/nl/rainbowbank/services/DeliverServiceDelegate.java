package nl.rainbowbank.services;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class DeliverServiceDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("DeliverServiceDelegate");
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		execution.setVariable("deliveryStatus", "Delivered Successfully!");
		execution.setVariable("orderStatus", "Order Complete");
		String userName = (String) execution.getVariable("firstName");
		LOGGER.info("Credit Card is delivered for user: "+ userName);
	}

}
