package nl.rainbowbank.services;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CreateCardDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("CreateCardDelegate");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		execution.setVariable("cardStatus", "Printed");
		String userName = (String) execution.getVariable("firstName");
		LOGGER.info("Credit Card is printed for user: "+ userName);
	}
}
