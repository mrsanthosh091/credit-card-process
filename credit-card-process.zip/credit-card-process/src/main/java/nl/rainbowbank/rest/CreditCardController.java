package nl.rainbowbank.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import nl.rainbowbank.constants.ApplicationConstants;
import nl.rainbowbank.model.UserDetails;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("CreditCard")
public class CreditCardController {

	private final static Logger LOGGER = Logger.getLogger("CreditCardController");
	
	@Autowired
	RuntimeService runtimeService;

	@RequestMapping("/getProducts")
	public List<String> getCreditCardProducts(){
		List<String> availableProducts = null;
		try{
			availableProducts = new ArrayList<String>();
			availableProducts.add("Bronze-CreditCard");
			availableProducts.add("Gold-CreditCard");
			availableProducts.add("Platinum-CreditCard");
		}catch(Exception e){
			LOGGER.info(e.getLocalizedMessage());
			throw e;
		}
		return availableProducts;
	}

	@PostMapping("/selectProduct")
	public String selectProduct(@RequestBody UserDetails userData){
		String instanceId = null;
		try{
			ObjectMapper objMapper = new ObjectMapper();
			ProcessInstance instance = runtimeService.startProcessInstanceByKey(ApplicationConstants.PROCESS_KEY, objMapper.convertValue(userData, java.util.Map.class));
			instanceId = instance.getProcessInstanceId();
			LOGGER.info("Process Instance ID: "+instance.getProcessInstanceId());
		}catch(Exception e){
			LOGGER.info(e.getLocalizedMessage());
			throw e;
		}
		return "Thank you for your order! Kindly note the transaction ID: "+ instanceId+ " for future references. You will receive an email once the product is dispatched.";
	}
}
